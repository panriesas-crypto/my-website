
# Backend (Render)
Deploy as a Web Service. Build: `npm ci` (or `npm install`) — Start: `npm start`.
Set env: `DATABASE_URL` (Neon), `CORS_ORIGIN` (Vercel domain), others as needed.
