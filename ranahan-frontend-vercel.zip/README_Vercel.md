
# Frontend (Vercel)
Static HTML/JS site. `vercel.json` rewrites `/api/*` to Render backend.
Edit the destination domain before deploy.
