
# Neon (PostgreSQL)
Run `schema.sql` then `seed.sql` in the Neon SQL Editor. Copy the connection string to Render's `DATABASE_URL`.
